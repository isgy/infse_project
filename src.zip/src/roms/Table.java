package roms;

public class Table {

    private Menu menu;
	public Menu showMenu(){
    return menu.showItems();	
	}
	
	public void newTicket(){
		
	}
    public void showTicket() {
        // TO BE COMPLETED
    }
    public void addMenuItem(String menuID) {
        // TO BE COMPLETED
    }
    public void removeMenuItem(String menuID) {
        // TO BE COMPLETED
    }
    public void submitOrder() {
        // TO BE COMPLETED
    }
    public void payBill() {
        // TO BE COMPLETED
    }
}
