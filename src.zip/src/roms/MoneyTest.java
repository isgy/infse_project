/**
 * 
 */
package roms;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * @author pbj
 *
 */
public class MoneyTest {
    
    @Test
    public void testZero() {
        Money zero = new Money();
        assertEquals("0.00", zero.toString());
    }
    
    /*
     ***********************************************************************
     * BEGIN MODIFICATION AREA
     ***********************************************************************
     * Add all your JUnit tests for the Money class below.
     */
    

   /*
    * Put all class modifications above.
    ***********************************************************************
    * END MODIFICATION AREA
    ***********************************************************************
    */


}
